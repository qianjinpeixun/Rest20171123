a few screenshots showing sample runs of your program:

philosopher 1 is thinking.
philosopher 0 is thinking.
philosopher 2 is thinking.
philosopher 3 is thinking.
philosopher 4 is thinking.
philosopher 0 is hungry.
philosopher 0 is eating.
philosopher 1 is hungry.
philosopher 2 is hungry.
philosopher 2 is eating.
philosopher 3 is hungry.
philosopher 4 is hungry.
philosopher 2 is done eating.
philosopher 2 is thinking.
philosopher 3 is eating.
philosopher 0 is done eating.
philosopher 1 is eating.
philosopher 0 is thinking.
philosopher 1 is done eating.
philosopher 2 is hungry.
philosopher 1 is thinking.
philosopher 3 is done eating.
philosopher 0 is hungry.
philosopher 3 is thinking.
philosopher 2 is eating.
philosopher 4 is eating.
philosopher 1 is hungry.
philosopher 3 is hungry.
philosopher 2 is done eating.
philosopher 2 is thinking.
philosopher 4 is done eating.
philosopher 4 is thinking.
philosopher 3 is eating.
philosopher 1 is eating.
philosopher 4 is hungry.
philosopher 3 is done eating.
philosopher 3 is thinking.
philosopher 4 is eating.
philosopher 2 is hungry.
philosopher 1 is done eating.
philosopher 1 is thinking.
philosopher 2 is eating.
philosopher 3 is hungry.
philosopher 4 is done eating.
philosopher 4 is thinking.
philosopher 0 is eating.
philosopher 1 is hungry.
philosopher 2 is done eating.
philosopher 2 is thinking.
philosopher 3 is eating.
philosopher 0 is done eating.
philosopher 4 is hungry.
philosopher 0 is thinking.
philosopher 1 is eating.
philosopher 2 is hungry.
philosopher 3 is done eating.
philosopher 3 is thinking.
philosopher 4 is eating.
philosopher 1 is done eating.
philosopher 1 is thinking.
philosopher 0 is hungry.
philosopher 2 is eating.
philosopher 4 is done eating.
philosopher 3 is hungry.
philosopher 4 is thinking.
philosopher 0 is eating.
philosopher 1 is hungry.
philosopher 2 is done eating.
philosopher 2 is thinking.
philosopher 3 is eating.
philosopher 4 is hungry.
philosopher 0 is done eating.
philosopher 0 is thinking.
philosopher 1 is eating.
philosopher 2 is hungry.
philosopher 3 is done eating.
philosopher 3 is thinking.
philosopher 4 is eating.
philosopher 0 is hungry.
philosopher 1 is done eating.
philosopher 1 is thinking.
philosopher 2 is eating.
philosopher 3 is hungry.
philosopher 4 is done eating.
philosopher 4 is thinking.
philosopher 0 is eating.
philosopher 1 is hungry.
philosopher 2 is done eating.
philosopher 2 is thinking.
philosopher 3 is eating.
philosopher 4 is hungry.
philosopher 0 is done eating.
philosopher 0 is thinking.
philosopher 1 is eating.
philosopher 2 is hungry.
philosopher 3 is done eating.
philosopher 3 is thinking.
philosopher 4 is eating.
