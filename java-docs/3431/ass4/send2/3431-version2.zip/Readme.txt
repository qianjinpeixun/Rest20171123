RQ 1 4 5 6
*4*
*5*
*6*
Customer # 1 requesting 4 5 6 Available = 10 5 7 Approved
RL 2 5 7 8
*5*
*7*
*8*
Customer # 2 releasing 5 7 8 Available = 11 7 9 Allocated = -5 -7 -8 
RQ 3 10 20 30
*10*
*20*
*30*
Customer # 3 requesting 10 20 30 Available = 11 7 9 Denied
RQ 2 1 2 3
*1*
*2*
*3*
Customer # 2 requesting 1 2 3 Available = 11 7 9 Denied
RQ 2 1 2 2
*1*
*2*
*2*
Customer # 2 requesting 1 2 2 Available = 11 7 9 Approved
RQ 3 8 0 2
*8*
*0*
*2*
Customer # 3 requesting 8 0 2 Available = 10 5 7 Approved
RL 3 1 0 1
*1*
*0*
*1*
Customer # 3 releasing 1 0 1 Available = 3 5 6 Allocated = 7 0 1 
