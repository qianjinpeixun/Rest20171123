import Tkinter 
root = Tkinter.Tk() 
w = Tkinter.Label(root, text="Hello, world!") 
w.pack()
root.mainloop()