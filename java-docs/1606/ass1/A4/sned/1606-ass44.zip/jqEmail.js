document.write("<script src=\"https://smtpjs.com/v2/smtp.js\"> </script>");
function sendemailforbonus() {
	
	Email.send("from@you.com","infx1606@gmail.com","BONUS for Assignment 4","For the contact form inA4.2, implement the JQuery functionality that lets you e-mail the message to a specified e-mailaddress, when the user clicks submit, i.e. in A4.3, display the alert confirmation and then useJQuery to send an e-mail.","smtp.gmail.com","infx1606","ABcd@1234");

}